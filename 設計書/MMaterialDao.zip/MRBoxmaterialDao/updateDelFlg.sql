update m_r_boxmaterial
set
   del_flg = /* delFlg */'1'
  ,ex_cnt = ex_cnt + 1
  ,upd_acc = /* accId */'abcd120'
  ,upd_date = CURRENT_TIMESTAMP
where
/*%if boxId != null */
  box_id = /* boxId */'123ABC'
/*%end */
/*%if mtId != null */
and
  mt_id = /* mtId */'123ABC'
/*%end */